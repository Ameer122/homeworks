#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "concurrent_list.h"

struct node {
	int value;
	pthread_mutex_t mutexnode;
	node * next;

	// add more fields
};

struct list {
	// add fields
	node* first;
	pthread_mutex_t mutexlist;
};

void print_node(node* node)
{
	// DO NOT DELETE
	if (node)
	{
		printf("%d ", node->value);
	}
}

list* create_list()
{
	list* templist; //Define a new list, then we use malloc.
	int key = 0;
	templist = (list*)malloc(sizeof(list));
	if (templist == NULL)
	{
		key = 1;
	}
	if (key == 0)
	{
		templist->first = NULL;
		pthread_mutex_init(&(templist->mutexlist), NULL);
		// add code here
		return templist; // Returns a pointer to the list
	}
	else
		return NULL;

}

void delete_list(list* _list)
{
	node *temp, *temper;
	int key = 0;
	if (_list == NULL)
	{
		key = 1;
	}
	if (_list->first == NULL)
	{
		key = 1;
	}
	else {
		if (key == 0)
		{
			temp = _list->first;
			while (temp != NULL)
			{

				temper = temp->next; // We used 2 nodes to free the list, so we can keep a pointer to the list and remove the current one
				free(temp); //removing the current node
				temp = temper; //as temper is already at "" list-->first-->next "" then we can put it as our current node
			}

			free(_list); // Once we are at this point, then list is already empty of its nodes we simply free it.
		}
	}
}

void insert_value(list* list, int value)
{
	if (list != NULL) // We simply check if the list is null or not, if it is then we can't insert a value to it.
	{
		pthread_mutex_lock(&(list->mutexlist)); //we have a lock in,
												//We have to deal with 2 possible options, 
												// 1 - The given list is empty
												// 2 - List is not empty

												//Changes

		node*  tempnode; //Creating a new node
		tempnode = (node*)malloc(sizeof(node)); // Same as above
		tempnode->value = value; //setting the new node value to the given value
		pthread_mutex_init(&(tempnode->mutexnode), NULL); // Locking

														  //End here
		if (list->first == NULL)
		{
			
			tempnode->next = NULL; //As its the only node ( since we are here ) therefore it has no next
			list->first = tempnode; //Pointing the start of the list to the new node
			pthread_mutex_unlock(&(list->mutexlist));
		}
		else if (list->first->value > value) // if we are here, then the value is less than the value of the node at the first of the list
		{
			
			tempnode->next = list->first; //putting the new node which has lower value at the start of the list ( both codes this and the one down )
			list->first = tempnode; // ^
			pthread_mutex_unlock(&list->mutexlist); //unlocking
		}
		else if (list->first->value <= value)
		{
			node* fnode;
			int key = 0;
			node* secnode;
			if (list->first != NULL)
				fnode = list->first;


			pthread_mutex_lock(&fnode->mutexnode);
			pthread_mutex_unlock(&list->mutexlist);
			if (list->first->next != NULL) // This checks if we only have one node
			{
				key = 0;
				secnode = list->first->next;
				pthread_mutex_lock(&secnode->mutexnode);
			}

			while (secnode != NULL && secnode->value <= value) // We do a while to run over the list and check where the new node ) of the given value should be done then we insert it 
			{
				pthread_mutex_unlock(&fnode->mutexnode);
				fnode = secnode;
				secnode = secnode->next;
				if (secnode != NULL)
					pthread_mutex_lock(&secnode->mutexnode);
				if (secnode == NULL)
				{
					key = 1;
				}
			}
			
			tempnode->next = fnode->next;
			fnode->next = tempnode;
			pthread_mutex_unlock(&fnode->mutexnode);



			if (secnode != NULL)
				pthread_mutex_unlock(&secnode->mutexnode);

		}
	}
}

void remove_value(list* list, int value)
{
	pthread_mutex_lock(&list->mutexlist);
	int key = 0;

	if (list != NULL)
	{
		node  *fnode;
		if (list->first != NULL)
		{
			fnode = list->first;
		}
		node *snode;


		if (fnode == NULL)
		{
			pthread_mutex_unlock(&list->mutexlist); // we unlock the list
		}


		if (fnode != NULL)
			pthread_mutex_lock(&fnode->mutexnode); // we lock the firstnode to avoid any possible mistakes with changes



		if (fnode->next == NULL)
		{
			key = 1; // we are working with one item in the list therefore we only check if its the value then done
			if (fnode->value == value)
			{
				free(list->first);
				pthread_mutex_unlock(&list->mutexlist);
				key = 3;
			}
		}

		else if (fnode->next != NULL)
			snode = fnode->next;
		// We will be dealing with more than one scenario, if the list is empty therefore we have nothing to remove
		// if the firstnode of the list it the given value then we remove and done, otherwise we will look for it

		if (fnode->value == value && key != 3) // we have more
		{

			list->first = fnode->next; // we only enter here if firstnode has a next.
			free(fnode);
			pthread_mutex_unlock(&list->mutexlist);
		}
		else if (key != 3)
		{

			pthread_mutex_unlock(&list->mutexlist);
			if (snode != NULL)
				pthread_mutex_lock(&snode->mutexnode);

			while (snode != NULL && snode->value != value) // if the loop breaks then we have 2 possible scenraios will be dealt down there
			{
				pthread_mutex_unlock(&fnode->mutexnode);
				fnode = snode;
				if (snode->next != NULL)
					snode = snode->next;
				else
					snode == NULL; // we will end without finding the value

				if (snode != NULL)
					pthread_mutex_lock(&snode->mutexnode); // locking before the second loop
			}
			if (snode == NULL) // first scenario, loop broke because of the first option then we ran over the lsit
							   //and didn't find the given value so we simply unlock it
			{
				pthread_mutex_unlock(&fnode->mutexnode);
			}
			else if (snode != NULL)
			{
				fnode->next = snode->next;
				free(snode);
				pthread_mutex_unlock(&fnode->mutexnode);
			}
		}
	}
	else if (key != 3) // The only way to get key to 3 is when there is only 1 value in the list and it is the value we are looking for, then we unlock the list
					   //from inside, otherwise we check if we got here since list is null then we simply unlock it
	{
		pthread_mutex_unlock(&list->mutexlist);
	}
}


void print_list(list* list)
{
	// add code here
	int key = 0;
	
	if (list == NULL)
	{
	
		key = 1;
	}
	if (key != 1)
	{
	if (list->first == NULL)
	{

		key = 1;
	}
	else if (key == 0) {
		pthread_mutex_lock(&(list->mutexlist));
		node* tempnode1 = list->first;
		while (tempnode1 != NULL)
		{
			print_node(tempnode1);
			tempnode1 = tempnode1->next;
		}
	}
}
	printf("\n"); // DO NOT DELETE
	if(key!=1)
	pthread_mutex_unlock(&list->mutexlist);
}

void count_list(list* list, int(*predicate)(int))
{
	pthread_mutex_lock(&(list->mutexlist)); // Lock before starting
	int count = 0; // DO NOT DELETE
	node* temp;
	if (list->first != NULL)
	{

		temp = list->first;
		while (temp != NULL)
		{
			if (predicate(temp->value))
			{
				count++;
			}

			temp = temp->next;
		}
	}
	// add code here

	printf("%d items were counted\n", count); // DO NOT DELETE
	pthread_mutex_unlock(&(list->mutexlist)); // Unlocking after we are finished.
}
